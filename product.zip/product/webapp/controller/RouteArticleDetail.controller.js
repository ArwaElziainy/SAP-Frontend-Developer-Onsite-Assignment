sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/m/MessageToast",
    "sap/ui/core/format/DateFormat",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], (Controller, History, MessageToast, DateFormat, Filter, FilterOperator) => {
    "use strict";

    return Controller.extend("product.controller.RouteArticleDetail", {
          formatter: {
            date(sDate) {
                if (!sDate) {
                    return "";
                }

                const iTimestamp = Number(String(sDate).replace(/\D/g, ""));
                return new Date(iTimestamp).toLocaleDateString();
            },

            statusText(sStatus) {
                return {
                    O: "Open",
                    W: "Waiting",
                    C: "Closed"
                }[sStatus] || sStatus;
            },

            statusState(sStatus) {
                return {
                    O: "Success",
                    W: "Warning",
                    C: "Error"
                }[sStatus] || "None";
            }
        },
       onInit() {
            const oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("RouteArticleDetail").attachPatternMatched(this.onObjectMatched, this);
            this.getOwnerComponent()
                .getRouter()
                .getRoute("RouteArticleDetail")
                .attachPatternMatched(this.onObjectMatched, this);
        },

        async onObjectMatched(oEvent) {
            const sArticleId = decodeURIComponent(
                oEvent.getParameter("arguments").ArticleId
            );
            const oView = this.getView();
            const oModel = oView.getModel("Articles");

            oView.setBusy(true);

            try {
                await oModel.dataLoaded();

                const aArticles = oModel.getProperty("/Articles") || [];
                const iArticleIndex = aArticles.findIndex(
                    (oArticle) => String(oArticle.ArticleId) === sArticleId
                );

                if (iArticleIndex === -1) {
                    oView.unbindElement("Articles");
                    MessageToast.show(`Article ${sArticleId} was not found`);
                    this.getOwnerComponent().getRouter().navTo("RouteArticleList", {}, true);
                    return;
                }

                oView.bindElement({
                    path: `/Articles/${iArticleIndex}`,
                    model: "Articles"
                });

                const oPreOrdersTable = this.byId("preorderTable");
                const oPreOrderBinding = oPreOrdersTable.getBinding("items");

                var oFilter = new Filter("ArticleId", FilterOperator.EQ, sArticleId);
                oPreOrderBinding.filter(oFilter);

            } catch {
                MessageToast.show("The article data could not be loaded");
            } finally {
                oView.setBusy(false);
            }
        },
          onNavBack() {
            const sPreviousHash = History.getInstance().getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                this.getOwnerComponent().getRouter().navTo("RouteArticleList", {}, true);
            }
        }

    });
});
