
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/format/DateFormat",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], (Controller, JSONModel, DateFormat, Filter, FilterOperator) => {
    "use strict";

    return Controller.extend("product.controller.ArticleList", {
    formatter: {
       date(sDate) {
                if (!sDate) {
                    return "";
                }

                const iTimestamp = Number(String(sDate).replace(/\D/g, ""));
                return new Date(iTimestamp).toLocaleDateString();
            },
            statusText(sStatus) {
                return {
                    O: "Open",
                    W: "Waiting",
                    C: "Closed"
                }[sStatus] || sStatus;
            },

            statusState(sStatus) {
                return {
                    O: "Success",
                    W: "Warning",
                    C: "Error"
                }[sStatus] || "None";
            }
    },
        onInit() {

        },
        onTableUpdatedFinished:function(oEvent){
            const iCount = oEvent.getParameter("total");
            this.byId("tableTitle").setText(`Articles ${iCount}`);
        },
        onSearch: function(oEvent){
            const sQuery = oEvent.getParameter("newValue");
            const oTable = this.byId("articleTable");
            const oBinding = oTable.getBinding("items");
            if(sQuery){
                var oFilter = new Filter({
                filters: [
                    new Filter("Description", FilterOperator.Contains, sQuery)
                ],and:false
            });
            oBinding.filter(oFilter);
            } else {
                oBinding.filter([]);
            }
            

        },
        onArticlePress: function (oEvent) {

            const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            const oItem = oEvent.getSource();
            const oCtx = oItem.getBindingContext("Articles");
            const sArticleId = oCtx.getProperty("ArticleId");
            // console.log(sArticleId);
            oRouter.navTo("RouteArticleDetail", {
                ArticleId: sArticleId
            });
        }
    });
});
