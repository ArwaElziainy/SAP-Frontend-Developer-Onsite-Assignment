sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/format/DateFormat"
], (Controller, JSONModel, DateFormat) => {
    "use strict";

    return Controller.extend("product.controller.ArticleList", {
    formatter: {
       date(sDate) {
                if (!sDate) {
                    return "";
                }

                const iTimestamp = Number(String(sDate).replace(/\D/g, ""));
                return new Date(iTimestamp).toLocaleDateString();
            },
            statusText(sStatus) {
                return {
                    O: "Open",
                    W: "Waiting",
                    C: "Closed"
                }[sStatus] || sStatus;
            },

            statusState(sStatus) {
                return {
                    O: "Success",
                    W: "Warning",
                    C: "Error"
                }[sStatus] || "None";
            }
    },
        onInit() {

        },
        onArticlePress: function (oEvent) {

            const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            const oItem = oEvent.getSource();
            const oCtx = oItem.getBindingContext("Articles");
            const sArticleId = oCtx.getProperty("ArticleId");
            // console.log(sArticleId);
            oRouter.navTo("RouteArticleDetail", {
                ArticleId: sArticleId
            });
        }
    });
});
