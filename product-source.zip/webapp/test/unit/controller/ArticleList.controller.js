/*global QUnit*/

sap.ui.define([
	"product/controller/ArticleList.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ArticleList Controller");

	QUnit.test("I should test the ArticleList controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
