sap.ui.define([
	"product/test/unit/controller/ArticleList.controller"
], function () {
	"use strict";
});
